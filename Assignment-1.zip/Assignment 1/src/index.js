const { unlink } = require("fs/promises");
const fs = require("fs/promises");


//write files
const myFileWriter = async (fileName, fileContent) => {
  try {
    const data = new Uint8Array(Buffer.from(fileContent));
    const promise = await fs.writeFile(fileName, data);
  } catch (err) {
    console.error(err);
  }
};
myFileWriter("msg.txt", "hello my write-file test case passed!!");


//read files
const myFileReader = async (fileName) => {
  try {
    const promise = await fs.readFile(fileName, "utf-8");
    console.log(promise);
  } catch (err) {
    console.error(err);
  }
};
myFileReader("msg.txt");


//update files
const myFileUpdater = async (fileName, fileContent) => {
  fs.appendFile(fileName, fileContent, (err) => {
    if (err) throw err;
    console.log('The "data to append" was not appended to file!');
  });
};
myFileUpdater("msg.txt", "\n appended appended again");
myFileUpdater("test.txt", "\n appended appended again");
myFileUpdater("test2.txt", "\n appended appended again 2nd time");



//delete files
const myFileDeleter = async (fileName) => {
  unlink(fileName, (err) => {
    if (err) throw err;
    console.log(`${fileName} was deleted!!`);
  });
};

myFileDeleter("msg.txt");
// myFileDeleter("test.txt");
// myFileDeleter("test2.txt");

module.exports = { myFileWriter, myFileUpdater, myFileReader, myFileDeleter };
