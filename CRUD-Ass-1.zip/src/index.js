const fs = require('fs/promises')

const myFileWriter = async (fileName, fileContent) => {
	fs.writeFile("demo.txt", "This is my first assignment", (err) => {
		    console.log(err);
		     console.log("Write operation is completed");
		 })
	// write code here
	// dont chnage function name
}

const myFileReader = async (fileName) => {
	fs.readFile('./demo.txt', 'utf8', function (err,data) {
		if (err) {
		  return console.log(err);
		}
		console.log(data);
	  });
	// write code here
	// dont chnage function name
}


const myFileUpdater = async (fileName, fileContent) => {
	fs.appendFile("demo.txt", `\n Hi I am Updating text`, (err) => {
    console.log(err);
})
	// write code here
	// dont chnage function name
}

const myFileDeleter = async (fileName) => {
	fs.unlink("module.js", (err) => {
		    console.log(err);
		})
	// write code here
	// dont chnage function name
}



module.exports = { myFileWriter, myFileUpdater, myFileReader, myFileDeleter }
myFileWriter("../src/index.js")
myFileReader()
myFileUpdater()
myFileDeleter()